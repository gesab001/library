/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import gui.*;
import java.util.ArrayList;

/**
 *
 * @author 14400
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            Library library = new Library();
 //           ArrayList<Borrower> borrower = library.getBorrowerInformation(1111);
 //           Account account = new Account(10, 6, "01-44-2022", 333);
  //          System.out.print(account.getAccountNo());
            
 //           String result = library.addAccount(account);
 //           System.out.print(result);
//            Item item = new Item("asdf", "adsfd", "adfadsf", "asdfad");
//            library.connectToLibraryDatabase("admin", "admin");
//           // account.creditAmount(1234, 10);
//            account.debitAmount(1234, 10);
//
//            account.getAccountDetails(1234);
//            account.getBalance(1234);
//            library.getLoan(3333);
//            library.addItem(item, "Item");
             new LoginActivity().setVisible(true);
   //         new CheckIn().setVisible(true);
//              String message = library.removeItem("computing111");
//              System.out.print(message);
//            Item item = library.getItem("apple123");
//           System.out.print(item.getTitle());
//        ArrayList<Item> itemslist = library.getItems("apple");
//        if (itemslist.isEmpty()){
//            System.out.print("item doesn't exist");
//
//        }else{
//            for (Item itemfound : itemslist){
//              String item_info = itemfound.itemToString();
////            String title = item.getTitle();
////            String author = item.getAuthor();
////            String keywords = item.getKeywords();
////            String type = item.getType();
////            String status = item.getStatus();
////            String item_info = "Title: " + title + "\nAuthor: " + author + "\nKeywords: " + keywords + "\nType: " + type + "\nStatus: " + status;
//              System.out.print(item_info);
//              System.out.print("\n\n");
//            }
//        }
            
        
            
                

    }
    
}
